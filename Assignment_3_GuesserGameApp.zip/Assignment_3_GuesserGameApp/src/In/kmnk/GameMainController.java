package In.kmnk;

import java.util.Scanner;

public class GameMainController {
	public static void main(String[] args) {
		int guessableNumber = 0;

		int[] guessedNumbers = null;

		Scanner sc = new Scanner(System.in);

		System.out.print("Enter Number Of Players: ");
		int numberOfPlayesr = sc.nextInt();

		Empire ep = new Empire();

		guessableNumber = ep.collectNumberFromGenerator(guessableNumber);
		guessedNumbers = ep.collectNumberFromPlayer(numberOfPlayesr, guessedNumbers);
		ep.compare(numberOfPlayesr, guessableNumber, guessedNumbers);

		
		sc.close();
	}

}
